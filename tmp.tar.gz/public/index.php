<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Levi LOL</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/skeleton/2.0.4/skeleton.min.css">
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="twelve columns">
                    <?php include '.content.php'; ?>
                </div>
            </div>
        </div>
    </body>
</html>
